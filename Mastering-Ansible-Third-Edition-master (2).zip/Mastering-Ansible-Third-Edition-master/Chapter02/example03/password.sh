#!/bin/sh
echo "a long password"
