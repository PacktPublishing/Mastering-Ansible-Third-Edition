# Instructions

Tested on:
- Windows Server 2016 Standard Edition build 14393

Run this command:

    winrm configSDDL default
