# Instructions

This is a theoretical playbook - application of it is left as an exercise for the reader as it will require an pool of servers to operate against. Some of the variables in the playbook will also need to be defined.

