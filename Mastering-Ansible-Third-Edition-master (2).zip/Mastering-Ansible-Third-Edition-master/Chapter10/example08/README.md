# Instructions

Tested on:
- CentOS 7.6
- Ansible 2.7.5

Run this playbook using the command:

    ansible-playbook -i mastery-hosts micro.yaml
    ansible-playbook -i mastery-hosts micro.yaml -e upgrade=true
