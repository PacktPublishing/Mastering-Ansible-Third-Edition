# Instructions

Tested on:
- CentOS 7.6
- Ansible 2.7.5
- Docker version 1.13.1

This Docker container can be built by simply running the following command in this directory from a user account that has permission to access the Docker daemon:

    docker build .

