# Instructions

Tested on:
- CentOS 7.6
- Ansible 2.7.5

Run this playbook using the command:

    ansible-doc -M library/ remote_copy | cat -
