# Instructions

Tested on:
- CentOS 7.6
- Ansible 2.7.5
- Cumulus VX 3.7.3

Note that this example is theoretical unless you have a Cisco IOS device to test against - however the code is as provided in the book. Configuring this for your environment and running it is left as an exercise for the reader.

