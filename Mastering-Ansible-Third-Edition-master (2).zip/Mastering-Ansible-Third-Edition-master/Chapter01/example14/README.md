# Instructions

Tested on:
- CentOS 7.6
- Ansible 2.7.5

Run this playbook with the following command:

    ansible-playbook -i priority-hosts -c local priorityordering.yaml
