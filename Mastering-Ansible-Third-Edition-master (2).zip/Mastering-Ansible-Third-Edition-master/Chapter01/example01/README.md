# Instructions

Tested on:
- CentOS 7.6
- Ansible 2.7.5

Run this command:

    ansible-playbook --version
