# Instructions

Tested on:
- CentOS 7.6
- Ansible 2.7.5

Run this playbook with the following command:

    ansible-playbook -i mastery-hosts -c local --limit frontend mastery.yaml
