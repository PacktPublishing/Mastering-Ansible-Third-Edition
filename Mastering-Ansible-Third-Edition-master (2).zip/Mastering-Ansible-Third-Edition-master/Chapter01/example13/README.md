# Instructions

Tested on:
- CentOS 7.6
- Ansible 2.7.5

This is an example of a filter blacklist as included in the book.
