# Instructions

Tested on:
- CentOS 7.6
- Ansible 2.7.5

This is a playbook snippet only - it cannot be run by itself but is included for completeness. Remember to set the indentation correctly if you incorporate it into your own playbook.
