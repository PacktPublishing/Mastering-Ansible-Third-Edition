# Instructions

Tested on:
- CentOS 7.6
- Ansible 2.7.5

With AWX installed, create a directory:

    sudo mkdir /var/lib/awx/projects/mastery

Copy the included `example.yaml` into this directory:

    sudo cp example.yaml /var/lib/awx/projects/mastery
